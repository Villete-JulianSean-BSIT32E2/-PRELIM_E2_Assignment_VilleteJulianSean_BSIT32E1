namespace PRELIM_E2_Assignment_VilleteJulianSean_BSIT32E1.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
