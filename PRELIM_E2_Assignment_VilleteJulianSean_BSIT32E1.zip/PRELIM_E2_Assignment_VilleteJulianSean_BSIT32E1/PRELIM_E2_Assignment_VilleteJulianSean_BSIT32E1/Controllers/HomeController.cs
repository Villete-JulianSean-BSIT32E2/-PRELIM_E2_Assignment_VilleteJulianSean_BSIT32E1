using Microsoft.AspNetCore.Mvc;
using PRELIM_E2_Assignment_VilleteJulianSean_BSIT32E1.Models;
using System.Diagnostics;

namespace PRELIM_E2_Assignment_VilleteJulianSean_BSIT32E1.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            
            ViewBag.Name = "Julian Sean P. Villete";
            ViewBag.Course = "BSIT";
            ViewBag.Section = "E2";
            return View();
        }

        public ActionResult Subject()
        {
            
            ViewBag.Subject = "IT Elective 3";
            ViewBag.Day = "Saturday";
            ViewBag.Time = "10:00 AM - 01:00 PM";
            return View();
        }
    }
}
