using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PRELIM_E2_Assignment_VilleteJulianSean_BSIT32E1.Views.Home
{
    public class SubjectModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
